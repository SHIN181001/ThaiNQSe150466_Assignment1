﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WPFBo.Models;



namespace WPFDao
{
    public class ProductDao
    {
        private static ProductDao instance = null;
        private static readonly object instanceLock = new object();
        private ProductDao() { }

        public static ProductDao Instance
        {
            get
            {
                lock (instanceLock)
                {
                    if (instance == null)
                    {
                        instance = new ProductDao();
                    }
                    return instance;
                }
            }
        }
        public IEnumerable<Product> GetProducts()
        {
            List<Product> products;
            try
            {
                var myContext = new ElectricStoreDBContext();
                products = myContext.Products.ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return products;
        }
        public void AddProduct(Product product)
        {
            try
            {
                var myContext = new ElectricStoreDBContext();
                myContext.Products.Add(product);
                myContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        public Product GetProductByID(int productID)
        {
            Product product = null;
            try
            {
                var myContext = new ElectricStoreDBContext();
                product = myContext.Products.SingleOrDefault(p => p.Id == productID);

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return product;
        }
        public void RemoveProduct(Product product)
        {

            try
            {
                Product _product = GetProductByID(product.Id);
                if (_product != null)
                {
                    var myContext = new ElectricStoreDBContext();
                    myContext.Products.Remove(_product);
                    myContext.SaveChanges();
                }
                else
                {
                    throw new Exception("Product not exists!");
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void UpdateProduct(Product product)
        {
            try
            {
                Product _product = GetProductByID(product.Id);
                if (_product != null)
                {
                    var myContext = new ElectricStoreDBContext();
                    myContext.Entry(product).State = EntityState.Modified;
                    myContext.SaveChanges();
                }
                else
                {
                    throw new Exception("Product not exists!");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public IEnumerable SearchProduct(string id, string name, string productPrice, string unitsInStock)
        {
            List<Product> products = null;
            try
            {
                var myContext = new ElectricStoreDBContext();
                products = myContext.Products.Where(p => p.Id.ToString().Contains(id) && p.ProductName.Contains(name) && p.Price.ToString().Contains(productPrice)).ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return products;
        }
    }
    

}


