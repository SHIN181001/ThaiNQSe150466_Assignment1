﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WPFBo.Models;

namespace WPFDao
{
    public class CategoryDao
    {
        private static CategoryDao instance;
        private static readonly object instanceLock = new object();
        private CategoryDao() { }
        public static CategoryDao Instance
        {
            get
            {
                lock (instanceLock)
                {
                    if (instance == null)
                    {
                        instance = new CategoryDao();
                    }
                    return instance;
                }
            }
        }
        public Category GetCategoryByID(int categoryID)
        {
            Category category = null;
            try
            {
                var myContext = new ElectricStoreDBContext();
                category = myContext.Categories.SingleOrDefault(o => o.Id == categoryID);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return category;
        }
        public IEnumerable<Category> GetAllCategory()
        {
            List<Category> categorys;
            try
            {
                var myContext = new ElectricStoreDBContext();
                categorys = myContext.Categories.ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return categorys;
        }
        public void AddCategory(Category category)
        {
            try
            {
                var myContext = new ElectricStoreDBContext();
                myContext.Categories.Add(category);
                myContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void DeleteCategory(Category category)
        {
            try
            {
                Category _category = GetCategoryByID(category.Id);
                if (_category != null)
                {
                    var myContext = new ElectricStoreDBContext();
                    myContext.Categories.Remove(_category);
                    myContext.SaveChanges();
                }
                else
                {
                    throw new Exception("Category not found");
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void UpdateCategory(Category category)
        {
            try
            {
                Category _category = GetCategoryByID(category.Id);
                if (_category != null)
                {
                    var myContext = new ElectricStoreDBContext();
                    myContext.Entry<Category>(category).State = EntityState.Modified;
                    myContext.SaveChanges();
                }
                else
                {
                    throw new Exception("Category not found");
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
    
 
}
