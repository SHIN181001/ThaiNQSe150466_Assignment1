﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WPFBo.Models;

namespace WPFDao
{
    public class UserDao
    {
        public readonly ElectricStoreDBContext _dbContext = new();
        private static UserDao instance = null;
        private static readonly object instancelock = new object();
        public static UserDao Instance
        {
            get
            {
                lock (instancelock)
                {
                    if (instance == null)
                    {
                        instance = new UserDao();
                    }
                }
                return instance;
            }
        }

        public void DeleteUser(User user)
        {
            try
            {
                User _user = GetUserByID(user.UserId);
                if (_user != null)
                {
                    var myContext = new ElectricStoreDBContext();
                    myContext.Users.Remove(_user);
                    myContext.SaveChanges();
                }
                else
                {
                    throw new Exception("User not exists!");
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
            public IEnumerable<User> GetUsers()
    {
        List<User> users;
        try
        {
            var myContext = new ElectricStoreDBContext();
            users = myContext.Users.ToList();
        }
        catch (Exception ex)
        {

            throw ex;
        }
        return users;
    }
    public User GetUserByID(int userID)
    {
        User user = null;
        try
        {
                var myContext = new ElectricStoreDBContext();
                user = myContext.Users.SingleOrDefault(a => a.UserId == userID);
        }
        catch (Exception ex)
        {

            throw ex;
        }
        return user;
    }
    public void InsertUser(User user)
    {
        try
        {
            var myContext = new ElectricStoreDBContext();
            myContext.Users.Add(user);
            myContext.SaveChanges();
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public void UpdateUser(User user)
    {
        try
        {
            User _user = GetUserByID(user.UserId);
            if (user != null)
            {
                var myContext = new ElectricStoreDBContext();
                myContext.Entry<User>(user).State = EntityState.Modified;
                myContext.SaveChanges();
            }
            else
            {
                throw new Exception("User not Exists!");
            }
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }
    }

}


    

