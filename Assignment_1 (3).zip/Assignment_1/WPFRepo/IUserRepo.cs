﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WPFBo.Models;



namespace WPFRepo
{
    public interface IUserRepo
    {
        IEnumerable<User> GetUsers();
        User GetUserByID(int userid);
        void UpdateUser(User user);
        void DeleteUser(User user);
        void InsertUser(User user);
    }
}
