﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WPFBo.Models;

namespace WPFRepo
{
    public interface ICategoryRepo
    {
        IEnumerable<Category> GetAllCategory();
        Category GetCategoryByID(int id);
        void AddCategory(Category category);
        void DeleteCategory(Category category);
        void UpdateCategory(Category ordcategoryer);

    }
}
