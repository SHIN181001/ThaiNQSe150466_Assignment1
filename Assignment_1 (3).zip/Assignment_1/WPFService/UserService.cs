﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WPFBo.Models;
using WPFDao;
using WPFRepo;

namespace WPFService
{
    public class UserService : IUserRepo
    {
       public void DeleteUser( User user)=> UserDao.Instance.DeleteUser(user);
        public User GetUserByID(int userID) => UserDao.Instance.GetUserByID(userID);

        public IEnumerable<User> GetUsers() => UserDao.Instance.GetUsers();

        public void InsertUser(User user) => UserDao.Instance.InsertUser(user);
        public void UpdateUser(User user) => UserDao.Instance.UpdateUser(user);


    }
}
