﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WPFBo.Models;
using WPFDao;
using WPFRepo;

namespace WPFService
{
    public class ProductService : IProductRepo
    {
        public void AddProduct(Product product) => ProductDao.Instance.AddProduct(product);


        public void DeleteProduct(Product product)=> ProductDao.Instance.RemoveProduct(product);

        public Product GetProductByID(int productID) => ProductDao.Instance.GetProductByID(productID);

        public IEnumerable<Product> GetProducts() => ProductDao.Instance.GetProducts();

        public IEnumerable SearchProduct(string id, string name, string productPrice, string unitsInStock) => ProductDao.Instance.SearchProduct(id, name, productPrice, unitsInStock);

        public void UpdateProduct(Product product) => ProductDao.Instance.UpdateProduct(product);
    }
}
