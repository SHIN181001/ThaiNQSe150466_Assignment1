﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WPFBo.Models;
using WPFDao;
using WPFRepo;

namespace WPFService
{
    public class CategoryService : ICategoryRepo
    {
        public void AddCategory(Category category) => CategoryDao.Instance.AddCategory(category);
       

        public void DeleteCategory(Category category) => CategoryDao.Instance.DeleteCategory(category);

        public IEnumerable<Category> GetAllCategory()=> CategoryDao.Instance.GetAllCategory();

        public Category GetCategoryByID(int id)=> CategoryDao.Instance.GetCategoryByID(id);

        public void UpdateCategory(Category ordcategoryer)=> CategoryDao.Instance.UpdateCategory(ordcategoryer);
    }
}
