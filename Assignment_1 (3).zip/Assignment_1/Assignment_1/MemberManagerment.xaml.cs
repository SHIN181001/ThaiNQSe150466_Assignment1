﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WPFBo.Models;
using WPFDao;
using WPFRepo;
using System.Data.SqlClient;
using WPFService;
using System.Diagnostics.Metrics;

namespace WPFSolution
{
    /// <summary>
    /// Interaction logic for MemberManagerment.xaml
    /// </summary>
    public partial class MemberManagerment : Window
    {
        public static bool isAddMember = false;
        public static User user = null;

        IUserRepo _userRepo;
        public MemberManagerment(WPFService.UserService userService)
        {
            InitializeComponent();
            _userRepo = userService;

        }

        private void lvMember_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (lvMember.SelectedItem !=null)
            {
                btnEdit.IsEnabled = true;
                btnDelete.IsEnabled = true;
            }
            else
            {
                btnEdit.IsEnabled=false;
                btnDelete.IsEnabled=false;
            }
            
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            LoadMemberList();
        }
        public void LoadMemberList()
        {
            lvMember.ItemsSource = _userRepo.GetUsers();
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            isAddMember = true;
            AddOrEditMember editMember = new AddOrEditMember((_userRepo));
            editMember.ShowDialog();
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            isAddMember = true;
            AddOrEditMember addMember = new AddOrEditMember((_userRepo));
            addMember.ShowDialog();
        }
    }
}
