﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WPFService;

namespace WPFSolution
{
    /// <summary>
    /// Interaction logic for AdminPage.xaml
    /// </summary>
    public partial class AdminPage : Window
    {
        public AdminPage()
        {
            InitializeComponent();
        }
        private void btnProductmanager_Click(object sender, RoutedEventArgs e)
        {
            ProductManagerment productManagerment = new ProductManagerment(new ProductService());
            productManagerment.Show();
            
        }

        private void btnmembermanager_Click(object sender, RoutedEventArgs e)
        {
            MemberManagerment memberManagerment = new MemberManagerment(new UserService());
            memberManagerment.Show();
            
        }

        private void btnCategoryManager_Click(object sender, RoutedEventArgs e)
        {
            CategoryManagerment categoryManagerment = new CategoryManagerment(new CategoryService());
            categoryManagerment.Show();
            
        }
    }
}
