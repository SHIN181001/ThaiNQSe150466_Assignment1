﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WPFBo.Models;

namespace WPFSolution
{
    /// <summary>
    /// Interaction logic for AddOrEditMember.xaml
    /// </summary>
    public partial class AddOrEditMember : Window
    {
        public AddOrEditMember(WPFRepo.IUserRepo _userRepo)
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                User user = MemberManagerment.user;
                clear();
                txtAddID.Text = user.UserId.ToString();
                txtName.Text = user.UserName;
                txtPassword.Text = user.Password;
                txtRole.Text = user.UserRole;

            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void clear()
        {
            txtName.Text = "";
            txtAddID.Text = "";
            txtPassword.Text = "";
            txtRole.Text = "";
        }
/*        private User GetMemberObject()
        {
            return new User(txtAddID.Text, txtName.Text, txtRole.Text, txtPassword.Text);
        }*/
    }
}
