﻿   using Microsoft.Extensions.Configuration;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WPFBo.Models;
using WPFDao;
using WPFRepo;
using WPFSolution;

namespace Assignment_1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        /*private readonly IUserRepo _userRepo;*/
        public static bool isAdmin = true;
        public static int memberID = -1;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            string username =txtUsername.Text;
            string password = txtPassword.Text;
            if (TryLoginAsAdmin(username, password))
            {
                // Đăng nhập thành công với tài khoản admin
                isAdmin = true;
                ShowAdminPage();
            }
            /*else if (TryLoginAsMember(username, password))
            {
                // Đăng nhập thành công với tài khoản thành viên
                isAdmin = false;
                ShowUserPage();
            }*/
            else
            {
                // Đăng nhập không thành công
                MessageBox.Show("Invalid username or password");
            }

        }
        private bool TryLoginAsAdmin(string username, string password)
        {
            return AdminCheck(username, password);
        }
        private Boolean AdminCheck(string username, string password)
        {
            
            var admin = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).
                AddJsonFile("appsetting.json").Build().GetSection("Admin");

            if (!admin.Equals(username) || !admin.Equals(password))
            {
                return true;
            }
            return false;
        }
/*        private bool TryLoginAsMember(string username, string password)
        {
            var members = UserDao.Instance.GetUsers();
            var authenticatedMember = members.FirstOrDefault(member =>
                !string.IsNullOrEmpty(member.UserName) && !string.IsNullOrEmpty(member.Password) &&
                member.UserName.Trim().Equals(username) && member.Password.Equals(password));

            if (authenticatedMember != null)
            {
                memberID = authenticatedMember.UserId;
                return true;
            }

            return false;
        }*/

        private void ShowAdminPage()
            {
                AdminPage adminPage = new AdminPage();
                adminPage.Show();
                Hide();
                adminPage.Closed += (s, args) =>
                {
                    txtUsername.Clear();
                    txtPassword.Clear();
                    isAdmin = false;
                    memberID = -1;
                    Show();
                };
            }
       /* private void ShowUserPage()
        {
            UserPage userPage = new UserPage();
            userPage.Show();
            Hide();
            userPage.Closed += (s, args) =>
            {
                txtUsername.Clear();
                txtPassword.Clear();
                isAdmin = true;
                memberID = -1;
                Show();
            };
        }*/

    }
   
}