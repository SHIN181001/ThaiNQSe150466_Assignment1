﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WPFRepo;

namespace WPFSolution
{
    /// <summary>
    /// Interaction logic for CategoryManagerment.xaml
    /// </summary>
    public partial class CategoryManagerment : Window
    {
        ICategoryRepo _categoryrepo;
        public CategoryManagerment(WPFService.CategoryService categoryService)
        {
            InitializeComponent();
            _categoryrepo = categoryService;
        }

        private void lvCategory_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (lvCategory.SelectedItem != null)
            {
                btnEdit.IsEnabled = true;
                btnDelete.IsEnabled = true;
            }
            else
            {
                btnEdit.IsEnabled = false;
                btnDelete.IsEnabled = false;
            }
        }
        public void LoadCategoryList()
        {
            lvCategory.ItemsSource = _categoryrepo.GetAllCategory();
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            LoadCategoryList();
        }
    }
}
