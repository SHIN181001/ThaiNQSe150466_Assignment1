﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WPFBo.Models;
using WPFRepo;

namespace WPFSolution
{
    /// <summary>
    /// Interaction logic for ProductManagerment.xaml
    /// </summary>
    public partial class ProductManagerment : Window
    {
        IProductRepo _productrepo;
        public ProductManagerment(WPFService.ProductService productService)
        {
            InitializeComponent();
            _productrepo = productService;
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            LoadProductList();
        }
        public void LoadProductList()
        {
            lvProduct.ItemsSource = _productrepo.GetProducts();
        }

        private void lvProduct_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (lvProduct.SelectedItem != null)
            {
                btnEdit.IsEnabled = true;
                btnDelete.IsEnabled = true;
            }
            else
            {
                btnEdit.IsEnabled = false;
                btnDelete.IsEnabled = false;
            }

        }
    }
}
